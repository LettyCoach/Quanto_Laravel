<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RecController;
use App\Http\Controllers\EtrController;
use App\Http\Controllers\UsrController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| 申し込み生徒用ルーティング
|--------------------------------------------------------------------------
|
*/

Route::get('/' . config('custom.student_folder') . '/login', [UsrController::class, 'login']);
Route::post('/' . config('custom.student_folder') . '/login-student', [UsrController::class, 'LoginStudent']);
Route::get('/' . config('custom.student_folder') . '/register', [UsrController::class, 'register']);
Route::post('/' . config('custom.student_folder') . '/register-student', [UsrController::class, 'registerStudent']);
Route::post('/' . config('custom.student_folder') . '/fetch-cities', [UsrController::class, 'fetchCity']);
Route::post('/' . config('custom.student_folder') . '/fetch-schools', [UsrController::class, 'fetchSchool']);

/*
|--------------------------------------------------------------------------
| 申し込み学校ルーティング
|--------------------------------------------------------------------------
|
*/

Route::get('/' . config('custom.appschool_folder') . '/login', function () {
    return view('etr.login');
});

/*
|--------------------------------------------------------------------------
| 募集学校ルーティング
|--------------------------------------------------------------------------
|
*/

Route::get('/' . config('custom.recschool_folder') . '/login', function () {
    return view('rec.login');
});
Route::post('/' . config('custom.recschool_folder') . '/staff', function () {
    return view('rec.staff');
});
Route::get('/' . config('custom.recschool_folder') . '/staff', function () {
    return view('rec.staff');
});

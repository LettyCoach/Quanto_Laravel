<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Student;

class UsrController extends Controller
{
    public function login()
    {
        $page_title= 'ログイン';

        $notifications = DB::table('t_information')
        ->where('del_flg',0)
        ->get();

        return view('usr.login', ['page_title' =>$page_title, 'notifications' => $notifications]);

    }

    public function LoginStudent(Request $request)
    {
        $page_title = 'ログイン';

        return view('usr.login', ['page_title' => $page_title]);
    }

    public function register()
    {

        $page_title = '新規アカウント登録';

        $recschools = DB::table('m_rec_school')
        ->where('del_flg', 0)
        ->get();

        $prefectures = DB::table('m_prefecture')
        ->where('delflg', 0)
        ->get();

        return view('usr.register', ['page_title' => $page_title, 'prefectures' => $prefectures, 'recschools' => $recschools]);

    }

    public function registerStudent(Request $request)
    {

        $request->validate([
            'rec_school' => 'required',
            'name' => 'required',
            'namekana' => 'required',
            'year' => 'required',
            'month' => 'required',
            'day' => 'required',
            'email' => 'required',
            'password' => 'required',
            'confirmpassword' => 'required',
            'prefecture' => 'required',
            'city' => 'required',
            'entry_school' => 'required',
            'phone' => 'required',
        ]);


        $email = $request->email;
        $isExists = Student::where('mail', $email)->first();

        if ($isExists) {

            return back()->withInput()->with('error-message', 'このメールアドレスはすでに登録されています');

        } else {

            if($request->password!=$request->confirmpassword){

                return back()->withInput()->with('error-message', 'パスワードが一致してません');

            }

            $student = new Student;
            $student->ety_school_cd = $request->entry_school;
            $student->studentname = $request->name;
            $student->studentnamekana = $request->namekana;
            $student->birth_date = $request->year.'-'.$request->month.'-'.$request->day;
            $student->pre_cd = $request->prefecture;
            $student->city_cd = $request->city;
            $student->tel = $request->phone;
            $student->mail = $request->email;
            $student->password = Hash::make($request->password);
            $student->status_kb = 1;
            $student->entry_kb = 1;
            $student->entry_nnd = now()->year;
            $student->token = $request->_token;
            $student->del_flg = 0;
            $student->create_date = now();
            $student->create_code ='';
            $response = $student->save();

            if($response){
                return back()->with('success-message', '仮登録メールを送信しました');
            }else{
                return back()->with('error-message', 'エラーが発生しました');
            }
        
        }
    }

    public function fetchCity(Request $request)
    {
        $data['cities'] = DB::table('m_city')
        ->where('pre_cd', $request->pre_cd)
        ->where('delflg', 0)
        ->get();
        return response()->json($data);
    }

    public function fetchSchool(Request $request)
    {
        $data['schools'] = 
        DB::table('m_entry_school')
        ->where('city_cd', $request->city_cd)
        ->where('del_flg', 0)
        ->get();

        return response()->json($data);
    }

}

@include('usr.header')
<div class="container">
    <div class="row mt-3">
        <h2 class="text-center my-5">体験入学申し込みフォーム</h2>
    </div>
    <div class="row mt-3">
        <div class="col-12 col-lg-6 pe-lg-5">
            <div class="mx-auto" style="max-width:500px;">
                <h3 class="text-center my-3">新着情報</h3>
                @foreach($notifications as $notification)
                <div class="bg-gray p-4 mb-1 w-100 float-end rounded">
                    <h5>{{ \Carbon\Carbon::parse($notification->post_date)->format('Y.m.d')}}　{{$notification->infotitle}}</h5>
                    <p>
                        {{$notification->infocontents}}
                    </p>
                </div>
                @endforeach
            </div>
        </div>
        <div class="col-12 col-lg-6 ps-lg-5 mt-lg-5" style="padding-top:100px;">
            <div class="mx-auto" style="max-width:500px;">
                <form method="POST" action="login-student">
                    @csrf
                    <div class="row mb-4">
                        <div class="col-4 pe-0">
                            <label for="email" class="form-label pt-2">メールアドレス</label>
                        </div>
                        <div class="col-8">
                            <input type="email" class="form-control" name="email" placeholder="" required>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-4 pe-0">
                            <label for="email" class="form-label pt-2">パスワード</label>
                        </div>
                        <div class="col-8">
                            <input type="password" class="form-control" name="email" placeholder="" required>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <button type="submit" class="btn btn-primary mx-auto" style="width:100px;">ログイン</button>
                    </div>
                </form>
                <div class="row mb-4">
                    <a href="register" class="btn btn-outline-primary mx-auto btn-hover-outline" style="width:200px;">初めての方はこちら</a>
                </div>
            </div>
        </div>
    </div>
</div>
@include('usr.footer')
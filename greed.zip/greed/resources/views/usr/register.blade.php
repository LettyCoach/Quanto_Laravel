@include('usr.header')
<div class="container">
    <div class="row mt-3">
        <h2 class="text-center my-5">アカウントの仮登録</h2>
    </div>
    <div class="row my-2">
        <h4 class="my-2">初めてのご利用の方は以下から登録をおこなってください</h4>
    </div>
    <div class="row mb-2">
        <div class="alert alert-primary">
            &nbsp;&nbsp;仮登録が完了すると「@kami-anet.com」というドメインから本登録用のURLがメールで届きます。メールが受信できるようにいん許可指定してください。</br>
            &nbsp;&nbsp;ドメイン許可した場合でもメールは迷惑メールフォルダに分類される場合がございます。</br>
            「利用規約」をよくお読みいただき、同意いただいた方のみご利用ください。
        </div>
    </div>
    <div class="row mt-3">
        <div class="card bg-white border-0 shadow-sm p-lg-5 p-4 mb-5">
            <form method="POST" action="register-student">
                @if(session()->has('success-message'))
                <div class="alert alert-success">
                    {{ session()->get('success-message') }}
                </div>
                @endif
                @if(session()->has('error-message'))
                <div class="alert alert-danger">
                    {{ session()->get('error-message') }}
                </div>
                @endif
                @if ($errors->any())
                <div class="alert alert-danger">
                    空欄があるので送信できません
                </div>
                @endif

                @csrf
                <div class="row my-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">体験入学対象学校</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <select class="form-select" name="rec_school">
                            <option value="">選択してください</option>
                            @foreach($recschools as $recschool)
                            @if (old('rec_school') == $recschool->rec_school_cd)
                            <option value="{{$recschool->rec_school_cd}}" selected>{{$recschool->schoolname}}</option>
                            @else
                            <option value="{{$recschool->rec_school_cd}}">{{$recschool->schoolname}}</option>
                            @endif
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生徒氏名</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="name" value="{{old('name')}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生徒氏名かな</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="namekana" value="{{old('namekana')}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生年月日</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="pe-2 float-start" style="width:40%;">
                            <select name="year" class="form-select">
                                <option value="">年</option>
                                @for ($year = date('Y'); $year > date('Y') - 50; $year--)
                                @if (old('year') == $year)
                                <option value="{{$year}}" selected>
                                    {{$year}}
                                </option>
                                @else
                                <option value="{{$year}}">
                                    {{$year}}
                                </option>
                                @endif
                                @endfor
                            </select>
                        </div>
                        <div class="float-start pe-1" style="width:30%;">
                            <select id="select_month" class="form-select" name="month">
                                <option value="">月</option>
                                @foreach(range(1,12) as $month)
                                @if (old('month') == $month)
                                <option value="{{$month}}" selected>
                                    {{strlen($month)==1 ? '0'.$month : $month}}
                                </option>
                                @else
                                <option value="{{$month}}">
                                    {{strlen($month)==1 ? '0'.$month : $month}}
                                </option>
                                @endif
                                @endforeach
                            </select>
                        </div>
                        <div class="float-start ps-1" style="width:30%;">
                            <select id="select_day" class="form-select" name="day">
                                <option value="">日</option>
                                @foreach(range(1,31) as $day)
                                @if (old('day') == $day)
                                <option value="{{strlen($day)==1 ? '0'.$day : $day}}" selected>
                                    {{strlen($day)==1 ? '0'.$day : $day}}
                                </option>
                                @else
                                <option value="{{strlen($day)==1 ? '0'.$day : $day}}">
                                    {{strlen($day)==1 ? '0'.$day : $day}}
                                </option>
                                @endif
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">メールアドレス</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="email" class="form-control" name="email" value="{{old('email')}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">パスワード</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="password" class="form-control" name="password" value="{{old('password')}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">パスワード（確認）</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="password" class="form-control" name="confirmpassword">
                        <p class="mt-3">※半角英数字を含む10文字以上20文字以下</p>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">所属の学校</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-10">
                        <div class="pe-lg-2 mb-2 pe-sm-1 float-start col-lg-3 col-sm-6">
                            <select id="select_prefecture" class="form-select" name="prefecture">
                                <option value="">(都道府県)</option>
                                @foreach($prefectures as $prefecture)
                                @if (old('prefecture') == $prefecture->pre_cd)
                                <option value="{{$prefecture->pre_cd}}" selected>{{$prefecture->pre_name}}</option>
                                @else
                                <option value="{{$prefecture->pre_cd}}">{{$prefecture->pre_name}}</option>
                                @endif
                                @endforeach
                            </select>
                        </div>
                        <div class="float-start pe-lg-1 ps-sm-1 mb-2 col-lg-3  col-sm-6">
                            <select id="select_city" class="form-select" name="city">
                                <option value="">(市区町村)</option>
                            </select>
                        </div>
                        <div class="float-start ps-lg-1 mb-2 col-lg-6  col-sm-12">
                            <select id="select_school" class="form-select" name="entry_school">
                                <option value="">(学校選択)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">電話番号</br>本人(または保護者）</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="phone" pattern="[0-9]{6,13}" maxlength="12" value="{{old('phone')}}">
                    </div>
                </div>
                <div class="row mb-4">
                    <button type="submit" class="btn btn-primary mx-auto" style="width:100px;">送信</button>
                </div>
            </form>
            <div class="row mb-4">
                <a href="login" class="btn btn-primary mx-auto" style="width:100px;">戻る</a>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        var prefecture = "{{old('prefecture')}}";
        var city = "{{old('city')}}";
        if (prefecture.length > 0) {
            $("#select_city").html('<option value="">(市区町村)</option>');
            $.ajax({
                url: "{{url('/' . config('custom.student_folder') . '/fetch-cities')}}",
                type: "POST",
                data: {
                    pre_cd: prefecture,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function(result) {
                    $('#select_city').html('<option value="">(市区町村)</option>');
                    $.each(result.cities, function(key, value) {
                        if ("{{old('city')}}" == value.city_cd) {
                            $("#select_city").append('<option value="' + value.city_cd + '" selected >' + value.city_name + '</option>');
                        } else {
                            $("#select_city").append('<option value="' + value.city_cd + '">' + value.city_name + '</option>');
                        }
                    });
                    if (city.length > 0) {
                        $('#select_school').html('<option value="">(学校選択)</option>');
                        $.ajax({
                            url: "{{url('/' . config('custom.student_folder') . '/fetch-schools')}}",
                            type: "POST",
                            data: {
                                city_cd: city,
                                _token: '{{csrf_token()}}'
                            },
                            dataType: 'json',
                            success: function(res) {
                                $('#select_school').html('<option value="">(学校選択)</option>');
                                $.each(res.schools, function(key, value) {
                                    if ("{{old('entry_school')}}" == value.ety_school_cd) {
                                        $("#select_school").append('<option value="' + value.ety_school_cd + '" selected >' + value.schoolname + '</option>');
                                    } else {
                                        $("#select_school").append('<option value="' + value.ety_school_cd + '">' + value.schoolname + '</option>');
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }
        $('#select_prefecture').on('change', function() {
            var pre_cd = this.value;
            $("#select_city").html('<option value="">(市区町村)</option>');
            $.ajax({
                url: "{{url('/' . config('custom.student_folder') . '/fetch-cities')}}",
                type: "POST",
                data: {
                    pre_cd: pre_cd,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function(result) {
                    $('#select_city').html('<option value="">(市区町村)</option>');
                    $.each(result.cities, function(key, value) {
                        $("#select_city").append('<option value="' + value.city_cd + '">' + value.city_name + '</option>');
                    });
                    $('#select_school').html('<option value="">(学校選択)</option>');
                }
            });
        });
        $('#select_city').on('change', function() {
            var city_cd = this.value;
            $('#select_school').html('<option value="">(学校選択)</option>');
            $.ajax({
                url: "{{url('/' . config('custom.student_folder') . '/fetch-schools')}}",
                type: "POST",
                data: {
                    city_cd: city_cd,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function(res) {
                    $('#select_school').html('<option value="">(学校選択)</option>');
                    $.each(res.schools, function(key, value) {
                        $("#select_school").append('<option value="' + value.ety_school_cd + '">' + value.schoolname + '</option>');
                    });
                }
            });
        });
    });
</script>
@include('usr.footer')
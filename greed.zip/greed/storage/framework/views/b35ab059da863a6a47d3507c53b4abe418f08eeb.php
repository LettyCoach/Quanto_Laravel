<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('custom.system_name')); ?> | ログイン</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="../css/style.css" rel="stylesheet" type="text/css" />

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
</head>

<body class="bg-light">
    <div class="container-fluid bg-white py-2 shadow-sm sticky-top" style="min-height:100px;">
        <div class="row">
            <div class="col-12 col-sm-6 px-3 px-lg-4 text-center text-sm-start">
                <a href=""><img src="../images/logo.png" style="height:80px;" alt="Logo"></a>
            </div>
            <div class="col-12 col-sm-6 px-3 px-lg-5 d-flex align-items-center justify-content-center justify-content-sm-end">
                <p class="my-4">ログイン</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-3 mt-lg-5">
            <div class="col-12 px-3 px-md-4 px-lg-5 text-center pt-4 pb-3">
                <img src="../images/angelnet-logo.png" style="height:70px;" alt="AngelLogo">
            </div>
            <h5 class="text-center my-0">体験入学管理画面システム</h5>
        </div>
        <div class="row mt-3">
            <div class="col-12 col-lg-6 px-3 mx-auto" style="padding-top:50px;">
                <div class="mx-auto" style="max-width:500px;">
                    <form>
                        <div class="row mb-4">
                            <div class="col-4 pe-0">
                                <label for="email" class="form-label pt-2">ログインID</label>
                            </div>
                            <div class="col-8">
                                <input type="text" class="form-control" name="" placeholder="" required>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col-4 pe-0">
                                <label for="email" class="form-label pt-2">パスワード</label>
                            </div>
                            <div class="col-8">
                                <input type="password" class="form-control" name="email" placeholder="" required>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <button type="submit" class="btn btn-primary mx-auto" style="width:100px;">ログイン</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\greed\resources\views/rec/login.blade.php ENDPATH**/ ?>
    <script src="../js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\greed\resources\views/usr/footer.blade.php ENDPATH**/ ?>
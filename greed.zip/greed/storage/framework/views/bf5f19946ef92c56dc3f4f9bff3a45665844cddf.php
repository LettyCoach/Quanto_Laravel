<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('custom.system_name')); ?> | 教職員アカウント管理</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="../css/style.css" rel="stylesheet" type="text/css" />

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
</head>

<body class="bg-light">
    <div class="container-fluid bg-white py-2 shadow-sm sticky-top" style="min-height:100px;">
        <div class="row">
            <div class="col-12 col-sm-6 px-3 px-lg-4 text-center text-sm-start">
                <a href=""><img src="../images/logo.png" style="height:80px;" alt="Logo"></a>
            </div>
            <div class="col-12 col-sm-6 px-3 px-lg-4 d-flex align-items-center justify-content-center justify-content-sm-end">
                <div style="width:200px" class="my-4">
                    <a href="/" class="mx-2">メニュー</a>
                    <a href="/" class="mx-2">ログアウト</a>
                </div>
                <div class="text-center float-end d-lg-block d-none" style="width:220px;">
                    <img src="../images/angelnet-logo.png" style="height:50px;" alt="AngelLogo">
                    <p class="text-center my-1 text-center">体験入学管理画面システム</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-3 mt-lg-5 d-block d-lg-none">
            <div class="col-12 px-3 px-md-4 px-lg-5 text-center">
                <img src="../images/angelnet-logo.png" style="height:55px;" alt="AngelLogo">
            </div>
            <p class="text-center my-1 text-center text-center">体験入学管理画面システム</p>
        </div>
        <div class="row mt-3">
            <div class="card bg-white border-0 shadow-sm p-4">
                <form method="GET">
                    <div class="row">
                        <div class="my-2 col-12 col-lg-2 col-sm-4">
                            <select class="custom-select form-control" name="">
                                <option value="0">本校</option>
                                <option value="1">申し込み学校</option>
                            </select>
                        </div>
                        <div class="my-2 col-12 col-lg-2 col-sm-4">
                            <select class="form-control" name="">
                                <option value="0">都道府県</option>
                            </select>
                        </div>
                        <div class="my-2 col-12 col-lg-2 col-sm-4">
                            <select class="form-control" name="">
                                <option value="0">市区町村</option>
                            </select>
                        </div>
                        <div class="my-2 col-12 col-lg-4 col-sm-8">
                            <input type="text" class="form-control" name="" placeholder="学校名を入力">
                        </div>
                        <div class="my-2 col-12 col-lg-2 col-sm-4 text-center text-sm-start">
                            <button type="submit" class="btn btn-primary" style="width:100px;">検索</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="../js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\greed\resources\views/rec/staff.blade.php ENDPATH**/ ?>
<?php echo $__env->make('usr.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row mt-3">
        <h2 class="text-center my-5">アカウントの仮登録</h2>
    </div>
    <div class="row my-2">
        <h4 class="my-2">初めてのご利用の方は以下から登録をおこなってください</h4>
    </div>
    <div class="row mb-2">
        <div class="alert alert-primary">
            &nbsp;&nbsp;仮登録が完了すると「@kami-anet.com」というドメインから本登録用のURLがメールで届きます。メールが受信できるようにいん許可指定してください。</br>
            &nbsp;&nbsp;ドメイン許可した場合でもメールは迷惑メールフォルダに分類される場合がございます。</br>
            「利用規約」をよくお読みいただき、同意いただいた方のみご利用ください。
        </div>
    </div>
    <div class="row mt-3">
        <div class="card bg-white border-0 shadow-sm p-lg-5 p-4 mb-5">
            <form method="POST" action="register-student">
                <?php echo e(old('name')); ?>

                <?php if(session()->has('success-message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success-message')); ?>

                </div>
                <?php endif; ?>
                <?php if(session()->has('error-message')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error-message')); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    空欄があるので送信できません
                </div>
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                <div class="row my-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">体験入学対象学校</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <select class="form-select" name="rec_school">
                            <option value="">選択してください</option>
                            <?php $__currentLoopData = $recschools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recschool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(old('rec_school') == $recschool->rec_school_cd): ?>
                            <option value="<?php echo e($recschool->rec_school_cd); ?>" selected><?php echo e($recschool->schoolname); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($recschool->rec_school_cd); ?>"><?php echo e($recschool->schoolname); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生徒氏名</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生徒氏名かな</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="namekana" value="<?php echo e(old('namekana')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">生年月日</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="pe-2 float-start" style="width:40%;">
                            <select name="year" class="form-select">
                                <option value="">年</option>
                                <?php for($year = date('Y'); $year > date('Y') - 50; $year--): ?>
                                <?php if(old('year') == $year): ?>
                                <option value="<?php echo e($year); ?>" selected>
                                    <?php echo e($year); ?>

                                </option>
                                <?php else: ?>
                                <option value="<?php echo e($year); ?>">
                                    <?php echo e($year); ?>

                                </option>
                                <?php endif; ?>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="float-start pe-1" style="width:30%;">
                            <select id="select_month" class="form-select" name="month">
                                <option value="">月</option>
                                <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('month') == $month): ?>
                                <option value="<?php echo e($month); ?>" selected>
                                    <?php echo e(strlen($month)==1 ? '0'.$month : $month); ?>

                                </option>
                                <?php else: ?>
                                <option value="<?php echo e($month); ?>">
                                    <?php echo e(strlen($month)==1 ? '0'.$month : $month); ?>

                                </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="float-start ps-1" style="width:30%;">
                            <select id="select_day" class="form-select" name="day">
                                <option value="">日</option>
                                <?php $__currentLoopData = range(1,31); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('day') == $day): ?>
                                <option value="<?php echo e(strlen($day)==1 ? '0'.$day : $day); ?>" selected>
                                    <?php echo e(strlen($day)==1 ? '0'.$day : $day); ?>

                                </option>
                                <?php else: ?>
                                <option value="<?php echo e(strlen($day)==1 ? '0'.$day : $day); ?>">
                                    <?php echo e(strlen($day)==1 ? '0'.$day : $day); ?>

                                </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">メールアドレス</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">パスワード</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">パスワード（確認）</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="password" class="form-control" name="confirmpassword">
                        <p class="mt-3">※半角英数字を含む10文字以上20文字以下</p>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">所属の学校</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-10">
                        <div class="pe-lg-2 mb-2 pe-sm-1 float-start col-lg-3 col-sm-6">
                            <select id="select_prefecture" class="form-select" name="prefecture">
                                <option value="">(都道府県)</option>
                                <?php $__currentLoopData = $prefectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('prefecture') == $prefecture->pre_cd): ?>
                                <option value="<?php echo e($prefecture->pre_cd); ?>" selected><?php echo e($prefecture->pre_name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($prefecture->pre_cd); ?>"><?php echo e($prefecture->pre_name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="float-start pe-lg-1 ps-sm-1 mb-2 col-lg-3  col-sm-6">
                            <select id="select_city" class="form-select" name="city">
                                <option value="">(市区町村)</option>
                            </select>
                        </div>
                        <div class="float-start ps-lg-1 mb-2 col-lg-6  col-sm-12">
                            <select id="select_school" class="form-select" name="entry_school">
                                <option value="">(学校選択)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col-12 col-sm-4 col-lg-2 pe-0">
                        <label class="form-label pt-2">電話番号</br>本人(または保護者）</label>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <input type="text" class="form-control" name="phone" pattern="[0-9]{6,13}" maxlength="12" value="<?php echo e(old('phone')); ?>">
                    </div>
                </div>
                <div class="row mb-4">
                    <button type="submit" class="btn btn-primary mx-auto" style="width:100px;">送信</button>
                </div>
            </form>
            <div class="row mb-4">
                <a href="login" class="btn btn-primary mx-auto" style="width:100px;">戻る</a>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        var prefecture = "<?php echo e(old('prefecture')); ?>";
        var city = "<?php echo e(old('city')); ?>";
        if (prefecture.length > 0) {
            $("#select_city").html('<option value="">(市区町村)</option>');
            $.ajax({
                url: "<?php echo e(url('/' . config('custom.student_folder') . '/fetch-cities')); ?>",
                type: "POST",
                data: {
                    pre_cd: prefecture,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(result) {
                    $('#select_city').html('<option value="">(市区町村)</option>');
                    $.each(result.cities, function(key, value) {
                        if ("<?php echo e(old('city')); ?>" == value.city_cd) {
                            $("#select_city").append('<option value="' + value.city_cd + '" selected >' + value.city_name + '</option>');
                        } else {
                            $("#select_city").append('<option value="' + value.city_cd + '">' + value.city_name + '</option>');
                        }
                    });
                    if (city.length > 0) {
                        $('#select_school').html('<option value="">(学校選択)</option>');
                        $.ajax({
                            url: "<?php echo e(url('/' . config('custom.student_folder') . '/fetch-schools')); ?>",
                            type: "POST",
                            data: {
                                city_cd: city,
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            dataType: 'json',
                            success: function(res) {
                                $('#select_school').html('<option value="">(学校選択)</option>');
                                $.each(res.schools, function(key, value) {
                                    if ("<?php echo e(old('entry_school')); ?>" == value.ety_school_cd) {
                                        $("#select_school").append('<option value="' + value.ety_school_cd + '" selected >' + value.schoolname + '</option>');
                                    } else {
                                        $("#select_school").append('<option value="' + value.ety_school_cd + '">' + value.schoolname + '</option>');
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }
        $('#select_prefecture').on('change', function() {
            var pre_cd = this.value;
            $("#select_city").html('<option value="">(市区町村)</option>');
            $.ajax({
                url: "<?php echo e(url('/' . config('custom.student_folder') . '/fetch-cities')); ?>",
                type: "POST",
                data: {
                    pre_cd: pre_cd,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(result) {
                    $('#select_city').html('<option value="">(市区町村)</option>');
                    $.each(result.cities, function(key, value) {
                        $("#select_city").append('<option value="' + value.city_cd + '">' + value.city_name + '</option>');
                    });
                    $('#select_school').html('<option value="">(学校選択)</option>');
                }
            });
        });
        $('#select_city').on('change', function() {
            var city_cd = this.value;
            $('#select_school').html('<option value="">(学校選択)</option>');
            $.ajax({
                url: "<?php echo e(url('/' . config('custom.student_folder') . '/fetch-schools')); ?>",
                type: "POST",
                data: {
                    city_cd: city_cd,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(res) {
                    $('#select_school').html('<option value="">(学校選択)</option>');
                    $.each(res.schools, function(key, value) {
                        $("#select_school").append('<option value="' + value.ety_school_cd + '">' + value.schoolname + '</option>');
                    });
                }
            });
        });
    });
</script>
<?php echo $__env->make('usr.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\greed\resources\views/usr/register.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('custom.system_name')); ?> | <?php echo e($page_title); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="../css/style.css" rel="stylesheet" type="text/css" />

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
</head>

<body class="bg-light">
    <div class="container-fluid bg-white py-2 shadow-sm sticky-top" style="height:100px;">
        <div class="row">
            <div class="col-12 col-sm-6 px-3 px-lg-4 text-center text-sm-start">
                <a href=""><img src="../images/logo.png" style="height:80px;" alt="Logo"></a>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\greed\resources\views/usr/header.blade.php ENDPATH**/ ?>